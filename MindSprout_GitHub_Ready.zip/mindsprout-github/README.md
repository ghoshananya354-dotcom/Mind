# MindSprout — GitHub Pages recreation

Static HTML/CSS/JavaScript recreation of the supplied Wix MindSprout site.

## Pages
- `/` — Home
- `/dashboard.html` — Dashboard
- `/companion.html` — Companion
- `/journal.html` — Journal
- `/mind-quest.html` — MindQuest
- `/weather.html` — Weather
- `/support.html` — Support
- `/profile.html` — Profile

## Deploy
1. Create a GitHub repository.
2. Upload all files from this folder.
3. Open Settings → Pages.
4. Select **Deploy from a branch**, choose `main` and `/root`.
5. Save.

The current version keeps the supplied Wix image assets as their original hosted URLs so the visual assets can remain unchanged. For a completely self-contained repository, download the original assets into `assets/` and replace those URLs in `index.html`.
